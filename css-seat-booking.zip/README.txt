A Pen created at CodePen.io. You can find this one at https://codepen.io/ArvindSPanicker/pen/QQVZmw.

 A simple proof-of-concept for an interface for booking seats on a plane.